<?php
require_once '../db.php';
$sql = "SELECT buku.*, pengarang.nama_pengarang 
        FROM buku 
        LEFT JOIN pengarang ON buku.id_pengarang = pengarang.id_pengarang";
$stmt = $pdo->query($sql);
$bukus = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Buku</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h2 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        table th {
            background-color: #f2f2f2;
        }
        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .btn {
            padding: 6px 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
        }
        .btn:hover {
            background-color: #45a049;
        }
        .action {
            display: flex;
            justify-content: space-around;
        }
    </style>
</head>
<body>
    <div style="text-align: left;">
        <h2>Daftar Buku</h2>
        <a href="create_buku.php" class="btn">Tambah Buku</a>
    </div>
    <table>
        <thead>
            <tr>
                <th>ID Buku</th>
                <th>Judul Buku</th>
                <th>Pengarang</th>
                <th>Penerbit</th>
                <th>Tahun Terbit</th>
                <th>Kategori Buku</th>
                <th>No. ISBN</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($bukus as $buku): ?>
            <tr>
                <td><?php echo htmlspecialchars($buku['id_buku']); ?></td>
                <td><?php echo htmlspecialchars($buku['judul_buku']); ?></td>
                <td><?php echo htmlspecialchars($buku['nama_pengarang']); ?></td>
                <td><?php echo htmlspecialchars($buku['penerbit']); ?></td>
                <td><?php echo htmlspecialchars($buku['tahun_terbit']); ?></td>
                <td><?php echo htmlspecialchars($buku['kategori_buku']); ?></td>
                <td><?php echo htmlspecialchars($buku['no_isbn']); ?></td>
                <td class="action">
                    <a href="update_buku.php?id=<?php echo $buku['id_buku']; ?>" class="btn">Edit</a>
                    <a href="delete_buku.php?id=<?php echo $buku['id_buku']; ?>" class="btn" onclick="return confirm('Apakah Anda yakin untuk menghapus buku ini?')">Hapus</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>