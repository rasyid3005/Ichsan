<?php
require_once '../db.php';

// Ambil ID buku dari parameter GET
$id_buku = isset($_GET['id']) ? $_GET['id'] : die('ID Buku tidak ditemukan.');

// Query untuk menghapus data buku berdasarkan ID
$sql_delete = "DELETE FROM buku WHERE id_buku = :id_buku";
$stmt_delete = $pdo->prepare($sql_delete);
$stmt_delete->execute(['id_buku' => $id_buku]);

header("Location: index_buku.php");
?>