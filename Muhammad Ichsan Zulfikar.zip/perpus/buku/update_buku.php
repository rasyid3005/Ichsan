<?php
require_once '../db.php';

// Ambil ID buku dari parameter GET
$id_buku = isset($_GET['id']) ? $_GET['id'] : die('ID Buku tidak ditemukan.');

// Ambil data buku berdasarkan ID
$sql_buku = "SELECT * FROM buku WHERE id_buku = :id_buku";
$stmt_buku = $pdo->prepare($sql_buku);
$stmt_buku->execute(['id_buku' => $id_buku]);
$buku = $stmt_buku->fetch(PDO::FETCH_ASSOC);

if (!$buku) {
    die('Buku tidak ditemukan.');
}

// Ambil daftar pengarang untuk dropdown
$sql_pengarang = "SELECT id_pengarang, nama_pengarang FROM pengarang";
$stmt_pengarang = $pdo->query($sql_pengarang);
$pengarangs = $stmt_pengarang->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $judul_buku = $_POST['judul_buku'];
    $id_pengarang = $_POST['id_pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $kategori_buku = $_POST['kategori_buku'];
    $no_isbn = $_POST['no_isbn'];

    // Query untuk update data buku
    $sql_update = "UPDATE buku 
                   SET judul_buku = :judul_buku, id_pengarang = :id_pengarang, 
                       penerbit = :penerbit, tahun_terbit = :tahun_terbit, 
                       kategori_buku = :kategori_buku, no_isbn = :no_isbn 
                   WHERE id_buku = :id_buku";
    $stmt_update = $pdo->prepare($sql_update);
    $stmt_update->execute([
        'judul_buku' => $judul_buku,
        'id_pengarang' => $id_pengarang,
        'penerbit' => $penerbit,
        'tahun_terbit' => $tahun_terbit,
        'kategori_buku' => $kategori_buku,
        'no_isbn' => $no_isbn,
        'id_buku' => $id_buku
    ]);

    header("Location: index_buku.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Buku</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h2 {
            color: #333;
            text-align: center;
        }
        form {
            max-width: 600px;
            margin: 0 auto;
            border: 1px solid #ddd;
            padding: 20px;
            background-color: #f9f9f9;
        }
        label {
            display: block;
            margin-bottom: 10px;
        }
        input[type="text"], select {
            width: calc(100% - 12px);
            padding: 6px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .btn {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
            margin-top: 10px;
            display: inline-block;
        }
        .btn:hover {
            background-color: #45a049;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h2>Edit Buku</h2>
    <form method="POST">
        <label for="judul_buku">Judul Buku:</label>
        <input type="text" id="judul_buku" name="judul_buku" value="<?php echo htmlspecialchars($buku['judul_buku']); ?>" required><br>
        
        <label for="id_pengarang">Pengarang:</label>
        <select id="id_pengarang" name="id_pengarang">
            <?php foreach ($pengarangs as $pengarang): ?>
                <option value="<?php echo $pengarang['id_pengarang']; ?>" <?php if ($pengarang['id_pengarang'] == $buku['id_pengarang']) echo 'selected'; ?>>
                    <?php echo $pengarang['nama_pengarang']; ?>
                </option>
            <?php endforeach; ?>
        </select><br>
        
        <label for="penerbit">Penerbit:</label>
        <input type="text" id="penerbit" name="penerbit" value="<?php echo htmlspecialchars($buku['penerbit']); ?>"><br>
        
        <label for="tahun_terbit">Tahun Terbit:</label>
        <input type="text" id="tahun_terbit" name="tahun_terbit" value="<?php echo htmlspecialchars($buku['tahun_terbit']); ?>"><br>
        
        <label for="kategori_buku">Kategori Buku:</label>
        <input type="text" id="kategori_buku" name="kategori_buku" value="<?php echo htmlspecialchars($buku['kategori_buku']); ?>"><br>
        
        <label for="no_isbn">No. ISBN:</label>
        <input type="text" id="no_isbn" name="no_isbn" value="<?php echo htmlspecialchars($buku['no_isbn']); ?>" required><br>
        
        <input type="submit" value="Update" class="btn">
    </form>
    <a href="index_buku.php" class="back-link">Kembali ke Daftar Buku</a>
</body>
</html>
