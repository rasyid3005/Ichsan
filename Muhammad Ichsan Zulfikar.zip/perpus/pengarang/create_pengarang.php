<?php
require_once '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_pengarang = $_POST['nama_pengarang'];
    $no_telp = $_POST['no_telp'];
    $email = $_POST['email'];
    $alamat = $_POST['alamat'];

    try {
        $sql = "INSERT INTO pengarang (nama_pengarang, no_telp, email, alamat) VALUES (:nama_pengarang, :no_telp, :email, :alamat)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'nama_pengarang' => $nama_pengarang,
            'no_telp' => $no_telp,
            'email' => $email,
            'alamat' => $alamat
        ]);

        $last_id = $pdo->lastInsertId();
        echo "ID terakhir yang dimasukkan: " . $last_id;
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pengarang</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h2 {
            color: #333;
            text-align: center;
        }
        form {
            max-width: 600px;
            margin: 0 auto;
            border: 1px solid #ddd;
            padding: 20px;
            background-color: #f9f9f9;
        }
        label {
            display: block;
            margin-bottom: 10px;
        }
        input[type="text"] {
            width: calc(100% - 12px);
            padding: 6px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .btn {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
            margin-top: 10px;
            display: inline-block;
        }
        .btn:hover {
            background-color: #45a049;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h2>Tambah Pengarang</h2>
    <form method="POST">
        <label for="nama_pengarang">Nama Pengarang:</label>
        <input type="text" id="nama_pengarang" name="nama_pengarang" required><br>
        
        <label for="no_telp">No. Telepon:</label>
        <input type="text" id="no_telp" name="no_telp"><br>
        
        <label for="email">Email:</label>
        <input type="text" id="email" name="email"><br>
        
        <label for="alamat">Alamat:</label>
        <input type="text" id="alamat" name="alamat"><br>
        
        <input type="submit" value="Tambah Pengarang" class="btn">
    </form>
    <a href="index_pengarang.php" class="back-link">Kembali ke Daftar Pengarang</a>
</body>
</html>