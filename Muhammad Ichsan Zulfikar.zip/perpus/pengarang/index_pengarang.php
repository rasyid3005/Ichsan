<?php
require_once '../db.php';
$sql = "SELECT * FROM pengarang";
$stmt = $pdo->query($sql);
$pengarangs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pengarang</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h2 {
            color: #333;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        table th {
            background-color: #f2f2f2;
        }
        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .btn {
            padding: 6px 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
        }
        .btn:hover {
            background-color: #45a049;
        }
        .action {
            display: flex;
            justify-content: space-around;
        }
    </style>
</head>
<body>
    <div style="text-align:center;">
        <h2>Daftar Pengarang</h2>
        <a href="create_pengarang.php" class="btn">Tambah Pengarang</a>
    </div>
    <table>
        <thead>
            <tr>
                <th>ID Pengarang</th>
                <th>Nama Pengarang</th>
                <th>No. Telepon</th>
                <th>Email</th>
                <th>Alamat</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($pengarangs as $pengarang): ?>
            <tr>
                <td><?php echo htmlspecialchars($pengarang['id_pengarang']); ?></td>
                <td><?php echo htmlspecialchars($pengarang['nama_pengarang']); ?></td>
                <td><?php echo htmlspecialchars($pengarang['no_telp']); ?></td>
                <td><?php echo htmlspecialchars($pengarang['email']); ?></td>
                <td><?php echo htmlspecialchars($pengarang['alamat']); ?></td>
                <td class="action">
                    <a href="update_pengarang.php?id=<?php echo $pengarang['id_pengarang']; ?>" class="btn">Edit</a>
                    <a href="delete_pengarang.php?id=<?php echo $pengarang['id_pengarang']; ?>" class="btn" onclick="return confirm('Apakah Anda yakin untuk menghapus pengarang ini?')">Hapus</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>