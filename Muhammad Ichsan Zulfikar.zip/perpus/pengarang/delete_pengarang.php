<?php
require_once '../db.php';

$id_pengarang = $_GET['id'];
$sql = "DELETE FROM pengarang WHERE id_pengarang = :id_pengarang";
$stmt = $pdo->prepare($sql);
$stmt->execute(['id_pengarang' => $id_pengarang]);
header("Location: index_pengarang.php");
?>
