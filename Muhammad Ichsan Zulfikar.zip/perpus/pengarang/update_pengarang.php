<?php
require_once '../db.php';

$id_pengarang = $_GET['id'];
$sql = "SELECT * FROM pengarang WHERE id_pengarang = :id_pengarang";
$stmt = $pdo->prepare($sql);
$stmt->execute(['id_pengarang' => $id_pengarang]);
$pengarang = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_pengarang = $_POST['nama_pengarang'];
    $no_telp = $_POST['no_telp'];
    $email = $_POST['email'];
    $alamat = $_POST['alamat'];

    $sql = "UPDATE pengarang SET nama_pengarang = :nama_pengarang, no_telp = :no_telp, email = :email, alamat = :alamat WHERE id_pengarang = :id_pengarang";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['nama_pengarang' => $nama_pengarang, 'no_telp' => $no_telp, 'email' => $email, 'alamat' => $alamat, 'id_pengarang' => $id_pengarang]);
    header("Location: index_pengarang.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pengarang</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h2 {
            color: #333;
            text-align: center;
        }
        form {
            max-width: 600px;
            margin: 0 auto;
            border: 1px solid #ddd;
            padding: 20px;
            background-color: #f9f9f9;
        }
        label {
            display: block;
            margin-bottom: 10px;
        }
        input[type="text"] {
            width: calc(100% - 12px);
            padding: 6px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .btn {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
            margin-top: 10px;
            display: inline-block;
        }
        .btn:hover {
            background-color: #45a049;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h2>Edit Pengarang</h2>
    <form method="POST">
        <label for="nama_pengarang">Nama Pengarang:</label>
        <input type="text" id="nama_pengarang" name="nama_pengarang" value="<?php echo htmlspecialchars($pengarang['nama_pengarang']); ?>" required><br>
        
        <label for="no_telp">No. Telepon:</label>
        <input type="text" id="no_telp" name="no_telp" value="<?php echo htmlspecialchars($pengarang['no_telp']); ?>"><br>
        
        <label for="email">Email:</label>
        <input type="text" id="email" name="email" value="<?php echo htmlspecialchars($pengarang['email']); ?>"><br>
        
        <label for="alamat">Alamat:</label>
        <input type="text" id="alamat" name="alamat" value="<?php echo htmlspecialchars($pengarang['alamat']); ?>"><br>
        
        <input type="submit" value="Simpan Perubahan" class="btn">
    </form>
    <a href="index_pengarang.php" class="back-link">Kembali ke Daftar Pengarang</a>
</body>
</html>